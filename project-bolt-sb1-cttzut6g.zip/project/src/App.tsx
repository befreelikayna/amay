import React, { useState } from 'react';
import { Download, Edit } from 'lucide-react';

interface PDFData {
  name: string;
  cin: string;
  enterprise: string;
}

function App() {
  const names = [
    'ABDEALI HASSOUK', 'ABDELAZIZ ELMAALI', 'ABDELGHANI FATHALLAH', 'ABDELKABIR FIKRI',
    'ABDELKARIM RABAH', 'ABDELLAH AIT GOUGOU', 'ABDELLAH SAAB', 'ABDELLATIF JENNAH',
    'ABDELMOULA EL MALH', 'ABDERAHIM AIT AHLIMA', 'ABDERAHIM LMLAH', 'ABDERRAHIM ZAROUAL',
    'ABDESSALAM IGLI', 'AHMED AMSILK', 'AMAL EL AKRI', 'ANAS CHNIOULI',
    'AZIZ TAHIRI', 'BENDAOUD ED DAOUDY', 'BOUCHAIB ASSAKAT', 'BOUCHAIB LOUZA',
    'BRAHIM OUIKHLEF', 'EL HOUSSINE ERRACHDY', 'ELHABIB AMOUNIR', 'FATIMA BOUAMER',
    'FATNA BOUKHAYR', 'HASSAN BOUFKRI', 'HASSAN HAMZA', 'HAYAT BELKHENATI',
    'HICHAM BICHOUR', 'HICHAM EL KILALI', 'IDRISS EZARHOUNI', 'ISMAIL MAJOUJ',
    'ISSAM TIGUEMI', 'JABIR KABBOUT', 'LMAACHI ERRACHDI', 'MOHAMED AIT SAID',
    'MOHAMED EDDASSER', 'MOHAMED JANHI', 'MOHAMED OMOUAA', 'MOUNIR FILLALI',
    'MOURAD BOURICH', 'MOUSTAPHA EL GHARBI', 'MUSTAPHA EL MANYANI', 'NOURDDINE ASSILA',
    'RAJAA MOUNTASSIR', 'REDOUANE EZZOUAOUI', 'SAMI SADIKI', 'SOUFIANE AIT HADDOU',
    'SOUFIANE SALIMI', 'THAMI ER-RAFAI', 'YASSIN ELKHAIMI', 'YOUSSEF AHL OMAR',
    'YOUSSEF EL HACHIMI', 'MBAREK EL HOUSNI EL ALAOUI', 'EN NAJEM ZOUGUANE', 'MOHAMED HAMIMID',
    'MOSSAAB AIT LHAJ', 'OUALID EL GHAZI', 'ABDELKHALEK BENOMAR', 'HOUSIN CHARKAOUI',
    'MAROUNE ZAHIDI', 'ABDELKRIM BAAOUICH', 'ABDELJAOUAD BAMHAOUT', 'ZAKARIA SADIK',
    'ABDELKABIR OUARRAK', 'ISMAIL AIT LAFKIH', 'KHALIL SAIRABBI', 'ISMAIL EL ABDELLAOUI'
  ];

  const [pdfData, setPdfData] = useState<PDFData[]>(
    names.map(name => ({ name, cin: '', enterprise: '' }))
  );

  const generatePDF = (data: PDFData) => {
    const content = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            @font-face {
              font-family: 'Calibri';
              src: local('Calibri');
            }
            
            body {
              font-family: 'Times New Roman', serif;
              font-size: 12pt;
              line-height: 1.5;
              width: 21cm;
              height: 29.7cm;
              margin: 0 auto;
              padding: 2cm;
              box-sizing: border-box;
            }
            
            .title {
              font-family: 'Calibri', sans-serif;
              font-size: 18pt;
              font-weight: bold;
              font-style: italic;
              text-align: center;
              text-decoration: underline;
              margin-bottom: 1.5cm;
            }
            
            .date {
              text-align: right;
              margin-bottom: 2cm;
              font-family: 'Times New Roman', serif;
              font-size: 12pt;
            }
            
            .info {
              margin-bottom: 2cm;
              font-family: 'Calibri', sans-serif;
              font-size: 12pt;
              font-weight: bold;
              font-style: italic;
            }
            
            .object {
              font-family: 'Calibri', sans-serif;
              font-size: 12pt;
              font-weight: bold;
              font-style: italic;
            }
            
            .enterprise {
              font-family: 'Calibri', sans-serif;
              font-size: 12pt;
              font-weight: bold;
              font-style: italic;
            }
            
            .content {
              margin-bottom: 2cm;
              text-align: justify;
              font-family: 'Times New Roman', serif;
              font-size: 12pt;
            }
            
            .signatures {
              display: flex;
              justify-content: space-between;
              margin-top: 3cm;
              font-family: 'Times New Roman', serif;
              font-size: 12pt;
            }
          </style>
        </head>
        <body>
          <div class="title">Autorisation de congé</div>
          
          <div class="date">
            Fait à : ........................... Le : 25/03/2025
          </div>

          <div class="info">
            <p>Nom Et Prénom : ${data.name}</p>
            <p>CIN : ${data.cin}</p>
          </div>

          <div class="content">
            <p class="object">Objet : Congé annuel payé</p>
            <p>Monsieur,</p>
            <p>
              Par la présente, j'atteste que l'entreprise <span class="enterprise">${data.enterprise || '...........................'}</span> m'a accordé six (5) jours de congé
              payé pour la période du 01/04/2025 au 05/04/2025, conformément à mes droits aux congés légaux.
            </p>
            <p>Veuillez agréer, Monsieur, l'expression de mes salutations distinguées.</p>
          </div>

          <div class="signatures">
            <div>Signature Salarié</div>
            <div>Signature Directeur</div>
          </div>
        </body>
      </html>
    `;

    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `autorisation_conge_${data.name.toLowerCase().replace(/\s+/g, '_')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleEdit = (index: number, field: keyof PDFData, value: string) => {
    const newData = [...pdfData];
    newData[index] = { ...newData[index], [field]: value };
    setPdfData(newData);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-center mb-8">Autorisations de Congé</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {pdfData.map((data, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-4">
            <h3 className="font-semibold text-lg mb-2">{data.name}</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  CIN
                </label>
                <input
                  type="text"
                  placeholder="Entrer CIN"
                  value={data.cin}
                  onChange={(e) => handleEdit(index, 'cin', e.target.value)}
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Entreprise
                </label>
                <input
                  type="text"
                  placeholder="Nom de l'entreprise"
                  value={data.enterprise}
                  onChange={(e) => handleEdit(index, 'enterprise', e.target.value)}
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="flex justify-between mt-4">
              <button
                onClick={() => generatePDF(data)}
                className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors"
              >
                <Download size={16} />
                Télécharger
              </button>
              <button
                className="flex items-center gap-2 bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition-colors"
              >
                <Edit size={16} />
                Modifier
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;